const base_url = "https://api.open-meteo.com/v1/forecast?";
const end_url = "&current=temperature_2m&hourly=temperature_2m&timezone=auto&past_days=3&forecast_days=3";
let chartInstance = null; 


function mapearDatos(datos) {
    document.getElementById("v_lat").innerText = datos.latitude;
    document.getElementById("v_long").innerText = datos.longitude;
    document.getElementById("v_alt").innerText = datos.elevation;
    document.getElementById("v_zone").innerText = datos.timezone;
    document.getElementById("v_temp").innerText = datos.current.temperature_2m + "°C";
    document.getElementById("v_hour").innerText = datos.current.time;
}


function cargarDatos() {
    const latitude = document.getElementById("latitud").value;
    const longitude = document.getElementById("longitud").value;

    if (!latitude || !longitude) {
        alert("Por favor, ingrese valores de latitud y longitud.");
        return;
    }

    const url = `${base_url}latitude=${latitude}&longitude=${longitude}${end_url}`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error("Error en la solicitud");
            }
            return response.json();
        })
        .then(data => {
            mapearDatos(data);
            actualizarGrafico(data.hourly.time, data.hourly.temperature_2m);
        })
        .catch(error => {
            console.error("Error:", error);
        });
}


function actualizarGrafico(labels, data) {
    const ctx = document.getElementById("grafico").getContext("2d");

    if (chartInstance) {
        chartInstance.destroy(); 
    }

    chartInstance = new Chart(ctx, {
        type: "line",
        data: {
            labels: labels.slice(0, 10),
            datasets: [{
                label: "Temperatura (°C)",
                data: data.slice(0, 10),
                borderColor: "blue",
                borderWidth: 2,
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: { title: { display: true, text: "Hora" } },
                y: { title: { display: true, text: "Temperatura (°C)" } }
            }
        }
    });
}
document.getElementById("buscar_datos").addEventListener("click", cargarDatos);


window.onload = function () {
    actualizarGrafico(
        ["2025-03-02T00:00", "2025-03-02T01:00", "2025-03-02T02:00", "2025-03-02T03:00", "2025-03-02T04:00"],
        [20.3, 20.5, 20.3, 20.1, 19.9]
    );
};
