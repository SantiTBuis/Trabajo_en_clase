let listaTareas = [];

// Función para agregar una tarea
function agregarTarea() {
    let input = document.getElementById("inputTarea");
    let nombreTarea = input.value.trim();

    if (nombreTarea === "") {
        alert("Por favor, ingrese una tarea válida.");
        return;
    }

    let tarea = {
        nombre: nombreTarea,
        completada: false
    };

    listaTareas.push(tarea);
    input.value = "";
    mostrarTareas();
}

// Función para mostrar la lista de tareas
function mostrarTareas() {
    let lista = document.getElementById("listaTareas");
    lista.innerHTML = "";

    listaTareas.forEach((tarea, index) => {
        let item = document.createElement("li");
        item.textContent = tarea.nombre;
        item.classList.add(tarea.completada ? "completada" : "noCompletada");

        // Alternar estado al hacer clic
        item.addEventListener("click", () => {
            tarea.completada = !tarea.completada;
            mostrarTareas();
        });

        lista.appendChild(item);
    });
}

// Evento para agregar tarea con el botón
document.getElementById("btnAgregarTarea").addEventListener("click", agregarTarea);

// Permitir agregar tarea con la tecla "Enter"
document.getElementById("inputTarea").addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
        agregarTarea();
    }
});
