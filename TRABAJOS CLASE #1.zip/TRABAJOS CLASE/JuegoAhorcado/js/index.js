let listaPalabras = ["perro", "gato", "nubes", "rocas", "flama"];
let palabraSecreta;
let intentosRestantes;
let letrasUsadas;

function obtenerPalabra() {
    return palabraSecreta
        .split("")
        .map(letra => (letrasUsadas.includes(letra) ? letra : "_"))
        .join(" ");
}

function iniciarJuego() {
    intentosRestantes = 6;
    letrasUsadas = [];
    palabraSecreta = listaPalabras[Math.floor(Math.random() * listaPalabras.length)];
    
    document.getElementById("intentosRestantes").textContent = intentosRestantes;
    document.getElementById("letrasUsadas").textContent = "";
    document.getElementById("palabra").textContent = obtenerPalabra();
    
    document.getElementById("jugar").disabled = true;
    document.getElementById("validar").disabled = false;
    document.getElementById("reiniciar").disabled = false;
}

function validarLetra() {
    let letra = document.getElementById("letra").value.toLowerCase();
    document.getElementById("letra").value = "";

    if (!letra || letrasUsadas.includes(letra) || letra.length !== 1) {
        alert("Ingrese una letra válida.");
        return;
    }

    letrasUsadas.push(letra);
    document.getElementById("letrasUsadas").textContent = letrasUsadas.join(", ");
    
    if (!palabraSecreta.includes(letra)) {
        intentosRestantes--;
        document.getElementById("intentosRestantes").textContent = intentosRestantes;
    }

    document.getElementById("palabra").textContent = obtenerPalabra();

    if (obtenerPalabra().replace(/\s/g, '') === palabraSecreta) {
        alert("¡Felicidades! Adivinaste la palabra.");
        finalizarJuego();
    } else if (intentosRestantes === 0) {
        alert(`Perdiste. La palabra era "${palabraSecreta}".`);
        finalizarJuego();
    }
}

function finalizarJuego() {
    document.getElementById("jugar").disabled = false;
    document.getElementById("validar").disabled = true;
    document.getElementById("reiniciar").disabled = true;
}

document.getElementById("jugar").addEventListener("click", iniciarJuego);
document.getElementById("validar").addEventListener("click", validarLetra);
document.getElementById("reiniciar").addEventListener("click", () => location.reload());
