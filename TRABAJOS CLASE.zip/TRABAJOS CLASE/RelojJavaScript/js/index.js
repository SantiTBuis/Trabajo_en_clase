let intervalo;
function actualizarReloj() {
    let fecha = new Date();
    let hora = fecha.getHours().toString().padStart(2, "0");
    let minutos = fecha.getMinutes().toString().padStart(2, "0");
    let segundos = fecha.getSeconds().toString().padStart(2, "0");

    document.getElementById("reloj").textContent = `${hora}:${minutos}:${segundos}`;
}

function iniciarReloj() {
    if (!intervalo) {
        actualizarReloj(); 
        intervalo = setInterval(actualizarReloj, 1000);
    }
}

function detenerReloj() {
    clearInterval(intervalo);
    intervalo = null;
}

document.getElementById("mostrar").addEventListener("click", iniciarReloj);
document.getElementById("detener").addEventListener("click", detenerReloj);
